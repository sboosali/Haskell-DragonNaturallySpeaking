//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by natlink.rc
//
#define IDS_PROJNAME                    100
#define IDR_APPSUPP                     101
#define IDD_STDOUT                      201
#define IDC_RICHEDIT                    201
#define IDR_MENU                        202
#define IDD_WAITFOR                     203
#define IDI_RIGHT                       204
#define IDI_RIGHT2                      205
#define IDI_DOWN                        206
#define IDI_DOWN2                       207
#define IDI_LEFT                        208
#define IDI_LEFT2                       209
#define IDI_UP                          210
#define IDI_UP2                         211
#define IDI_NODIR                       212
#define ID_OPTIONS_RELOAD               32768
#define ID_OPTIONS_DRAGLOG              32771
#define ID_WINDOW_TOPLEFT               32773
#define ID_WINDOW_TOPRIGHT              32774
#define ID_WINDOW_BOTTOMLEFT            32775
#define ID_WINDOW_BOTTOMRIGHT           32776
#define ID_WINDOW_REMEMBERPOSITION      32777
#define ID_WINDOW_CLEAR                 32778
#define ID_WINDOW_COPYTOCLIPBOARD       32779
#define ID_HELP_ABOUT                   32780
#define ID_WINDOW_SELECTALL             32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
