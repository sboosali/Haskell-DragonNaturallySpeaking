/*
 Python Macro Language for Dragon NaturallySpeaking
	(c) Copyright 1999 by Joel Gould
	Portions (c) Copyright 1999 by Dragon Systems, Inc.

 stdafx.cpp
 	source file that includes just the standard includes stdafx.pch will be
	the pre-compiled header stdafx.obj will contain the pre-compiled type
	information

 April 25, 1999
	- packaged for external release

 March 3, 1999
	- initial version
*/

#include "stdafx.h"

/*

08.28.2008 10:03 djr: Visual Studio 2005 claims these includes are obsolete.

#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#include <statreg.cpp>
#endif

#include <atlimpl.cpp>
*/