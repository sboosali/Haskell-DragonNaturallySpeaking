The release 3.9 has been removed because of a little bug.

The Vocola commands "edit commands" or "edit global commands" may crash NatSpeak. Please report if this happens.

Use natlinktest3.9lima (in folder natlinktest3.9) for the moment.

Quintijn