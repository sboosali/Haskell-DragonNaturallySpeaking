The release 3.8 is stable, but only for NatSpeak up to version 10 and Python2.5
